"use client";

// pages/index.tsx
import Link from "next/link";
import { useEffect, useState } from "react";

interface Pokemon {
  name: string;
  url: string;
}

export default function Home() {
  const [pokemons, setPokemons] = useState<Pokemon[]>([]);
  const [filtered, setFiltered] = useState<Pokemon[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("https://pokeapi.co/api/v2/pokemon?limit=151")
      .then((res) => res.json())
      .then((data) => {
        setPokemons(data.results);
        setFiltered(data.results);
      });
  }, []);

  useEffect(() => {
    const term = search.toLowerCase();
    setFiltered(pokemons.filter((p) => p.name.toLowerCase().includes(term)));
  }, [search]);

  return (
    <div className="min-h-screen p-4 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4 text-red-500">Pokemon Explorer</h1>
      <input
        className="w-full p-2 mb-4 border rounded"
        placeholder="Search Pokemon..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {filtered.map((pokemon, idx) => {
          const id = pokemon.url.split("/")[6];
          const image = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
          return (
            <Link key={pokemon.name} href={`/pokemon/${id}`}>
              <div className="bg-white rounded shadow p-4 text-center hover:bg-gray-50 cursor-pointer">
                <img src={image} alt={pokemon.name} className="mx-auto mb-2" />
                <p className="capitalize font-semibold text-red-200">
                  {pokemon.name}
                </p>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
