"use client";
import React from "react";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

export default function PokemonDetail() {
  const params = useParams();
  const id = params?.id;

  const [pokemon, setPokemon] = useState<any>(null);

  useEffect(() => {
    if (!id) return;
    fetch(`https://pokeapi.co/api/v2/pokemon/${id}`)
      .then((res) => res.json())
      .then((data) => setPokemon(data));
  }, [id]);

  if (!pokemon) return <div className="p-4 text-center">Loading...</div>;

  return (
    <div className="min-h-screen p-6 bg-white">
      <h1 className="text-4xl font-bold capitalize text-indigo-700 mb-4">
        {pokemon.name}
      </h1>
      <img
        src={pokemon.sprites.front_default}
        alt={pokemon.name}
        className="w-40 h-40 mx-auto mb-6"
      />
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Types</h2>
          <ul className="list-disc list-inside">
            {pokemon.types.map((t: any) => (
              <li key={t.type.name} className="capitalize text-red">
                {t.type.name}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">
            Abilities
          </h2>
          <ul className="list-disc list-inside">
            {pokemon.abilities.map((a: any) => (
              <li key={a.ability.name} className="capitalize">
                {a.ability.name}
              </li>
            ))}
          </ul>
        </div>
        <div className="md:col-span-2">
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Stats</h2>
          <ul className="space-y-1">
            {pokemon.stats.map((s: any) => (
              <li key={s.stat.name} className="capitalize">
                {s.stat.name}:{" "}
                <span className="font-medium">{s.base_stat}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="md:col-span-2">
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Moves</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {pokemon.moves.slice(0, 20).map((m: any) => (
              <span
                key={m.move.name}
                className="bg-gray-200 text-gray-700 rounded px-2 py-1 text-sm capitalize"
              >
                {m.move.name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
