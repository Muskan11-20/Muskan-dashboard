(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_pokemon_[id]_page_tsx_b741fd61._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_pokemon_[id]_page_tsx_b741fd61._.js",
  "chunks": [
    "static/chunks/_d0937de1._.js"
  ],
  "source": "dynamic"
});
