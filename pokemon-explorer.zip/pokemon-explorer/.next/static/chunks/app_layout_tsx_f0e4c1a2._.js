(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__98144f0b._.css"
  ],
  "source": "dynamic"
});
